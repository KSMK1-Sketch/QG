#include<stdio.h>
#include<stdlib.h>
#include<malloc.h>
#include"Linklist.h"


//�����ڵ�
struct Node* createNode(int data)
{
	struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
	newNode->data = data;
	newNode->left = newNode->right = NULL;

	return newNode;
}


struct List* createList()
{
	//�����ڴ�
	struct List* list = (struct List*)malloc(sizeof(struct List));
	//��ʼ������
	list->size = 0;
	list->firstNode = list->lastNode = NULL;

	return list;
}
//˫��������ͷ����
void insertNodeByHead(struct List* list, int data)
{
	struct Node* newNode = createNode(data);
	if (list->firstNode == NULL)
	{
		list->lastNode = newNode;
	}
	else
	{
		list->firstNode->left = newNode;
		newNode->right = list->firstNode;
	}
	list->firstNode = newNode;
	list->size++;
}
//˫��������β����
void insertNodeByTail(struct List* list, int data)
{
	struct Node* newNode = createNode(data);
	if (list->lastNode == NULL)
	{
		list->firstNode = newNode;
	}
	else
	{
		list->lastNode->right = newNode;
		newNode->left = list->lastNode;
	}
	list->lastNode = newNode;
	list->size++;

}
//˫������ָ��λ�ò���
void inserNodeByAppoin(struct List* list, int data, int posData)
{
	if (list->size == 0)
	{
		printf("����Ϊ�գ��޷�����");
		return;
	}
	else if (list->firstNode->data == posData)
	{
		insertNodeByHead(list, data);
	}
	else
	{
		struct Node* posNode = list->firstNode->right;
		struct Node* posNodeLeft = list->firstNode;
		while (posNode != NULL && posNode->data != posData)
		{
			posNodeLeft = posNode;
			posNode = posNodeLeft->right;
		}
		if (posNode == NULL)
		{
			printf("δ�ҵ���λ��,�޷����룡\n");
			return;
		}
		else
		{
			struct Node* newNode = createNode(data);
			posNodeLeft->right = newNode;
			newNode->left = posNodeLeft;
			newNode->right = posNode;
			posNode->left = newNode;
			list->size++;

		}
	}
}
//ɾ��
void deleteNode(struct List* list, int posData)
{

	if (list->size == 0)
	{
		printf("����Ϊ�գ��޷�ɾ��");
		return;
	}
	else if (list->firstNode->data == posData)
	{
		list->firstNode = list->firstNode->right;
		free(list->firstNode->left);
		list->firstNode->left = NULL;

		list->size--;

	}
	else if (list->lastNode->data == posData)
	{
		list->lastNode = list->lastNode->left;
		free(list->lastNode->right);
		list->lastNode->right = NULL;
		list->size--;

	}
	else
	{
		struct Node* posNode = list->firstNode->right;
		struct Node* posNodeLeft = list->firstNode;
		while (posNode != NULL && posNode->data != posData)
		{
			posNodeLeft = posNode;
			posNode = posNodeLeft->right;
		}
		if (posNode == NULL)
		{
			printf("δ�ҵ���λ��,�޷�ɾ����\n");
			return;
		}
		else if (posNode != NULL)
		{
			posNodeLeft->right = posNode->right;
			posNode->right->left = posNodeLeft;
			free(posNode);
			list->size--;

		}

	}
}
//˫��������ת
void reverseList(struct List* list)
{
	if ((list->size) <= 1)
	{
		return;
	}
	struct Node* curNode = list->firstNode;
	struct Node* leftNode = NULL;
	struct Node* rightNode = NULL;
	list->lastNode = curNode;
	while (curNode != NULL)
	{
		rightNode = curNode->right;

		curNode->right = leftNode;
		curNode->left = rightNode;

		leftNode = curNode;
		curNode = rightNode;//�ƶ���ǰָ��
	}
	list->firstNode = leftNode;
}
//�������ɻ�
void cycle(struct List* list)
{
	list->firstNode->left = list->lastNode;
	list->lastNode->right = list->firstNode;
}
//�ж������Ƿ�ɻ�
void judgeCycle(struct List* list)
{
	struct Node* fast = list->firstNode;
	struct Node* slow = list->firstNode;
	while (fast != NULL && fast->right != NULL)
	{
		slow = slow->right;
		fast = fast->right->right;		// ����ָ��������˵���л�
		if (slow == fast)
		{
			printf("�����ѳɻ�!\n");
			return;
		}
	}
	printf("����δ�ɻ�!\n");
}
//���Ҵ�ӡ����
void printListByRight(struct List* list)
{
	if (list->size == 0)
		printf("�޷���ӡ,����ΪNULL");
	else
	{
		struct Node* pMove = list->firstNode;
		while (pMove)
		{
			printf("%d-->", pMove->data);
			pMove = pMove->right;
		}
	}
	printf("NULL");
	printf("\n");

}
//�����ӡ����
void printListByLeft(struct List* list)
{
	if (list->size == 0)
		printf("�޷���ӡ,����ΪNULL");
	else
	{
		struct Node* pMove = list->lastNode;
		while (pMove)
		{
			printf("%d-->", pMove->data);
			pMove = pMove->left;
		}
	}
	printf("NULL");
	printf("\n");
}
