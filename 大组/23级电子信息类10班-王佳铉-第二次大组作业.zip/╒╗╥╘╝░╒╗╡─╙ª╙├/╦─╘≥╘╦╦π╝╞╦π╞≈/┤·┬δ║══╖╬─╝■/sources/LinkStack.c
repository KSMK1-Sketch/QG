#include "LinkStack.h"
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
//��ջ

//��ʼ��ջ
Status initLStack(LinkStack *s)
{
	if (!s) return ERROR;
	s->top = NULL;
	s->count = 0;
	return SUCCESS;
}

//�ж�ջ�Ƿ�Ϊ��
Status isEmptyLStack(LinkStack *s)
{
	if (s->count==0)
		return SUCCESS;//����1����ʾΪ��
	return ERROR;
}

//�õ�ջ��Ԫ��
Status getTopLStack(LinkStack *s,ElemType *e)
{

	if (s->count == 0)
		return ERROR;
	*e = s->top->data;
	return SUCCESS;
}

//���ջ
Status clearLStack(LinkStack *s)
{
	if (s->count == 0)
		return ERROR;
	
	StackNode* curNode = s->top->next;
	while (s->top->next)
	{
		curNode=curNode->next;
		free(s->top->next);
		s->top->next = curNode;
	}
	free(s->top->next);
	s->count = 0;
	return SUCCESS;
}

//����ջ
Status destroyLStack(LinkStack *s)
{
	if (!s)
		return ERROR;
	if (s->count == 0)
		return SUCCESS;
	clearLStack(s);
	free(s->top);
	return SUCCESS;
}

//���ջ����
Status LStackLength(LinkStack *s,int *length)
{
	if (s->count == 0)
		return ERROR;
	*length = s->count;
	return SUCCESS;
}

//��ջ
Status pushLStack(LinkStack *s,ElemType data)
{
	struct StackNode* newNode = (struct StackNode*)malloc(sizeof(struct StackNode));
	newNode->data = data;
	newNode->next = NULL;
	if (!s)
		return ERROR;
	if (s->count==0)
	{
		s->top = newNode;
	}
	else
	{
		newNode->next = s->top;
		s->top = newNode;
		
	}
	s->count++;
	return SUCCESS;
}

//��ջ
Status popLStack(LinkStack *s,ElemType *data)
{
	if (s->count == 0)
	{
		return ERROR;
	}
	else
	{
		*data = s->top->data;
		LinkStackPtr nextNode = s->top->next;
		free(s->top);
		s->top = nextNode;
		s->count--;
		return SUCCESS;
	}

}


