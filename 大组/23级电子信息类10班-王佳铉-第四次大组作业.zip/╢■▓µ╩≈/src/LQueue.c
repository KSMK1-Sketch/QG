#include "LQueue.h"
#include"binary_sort_tree.h"
#include <stdio.h>
#include <malloc.h>
#include <assert.h> 


/**
 *  @name        : void InitLQueue(LQueue *Q)
 *    @description : ��ʼ������
 *    @param         Q ����ָ��Q
 *  @notice      : None
 */
void* InitLQueue(LQueue* Q)
{
	Q->front = Q->rear = NULL;
	Q->length = 0;
}

/**
 *  @name        : Status EnLQueue(LQueue *Q, void *data)
 *    @description : ��Ӳ���
 *    @param         Q ����ָ��Q,�������ָ��data
 *    @return         : �ɹ�-TRUE; ʧ��-FALSE
 *  @notice      : �����Ƿ�Ϊ��
 */
Status EnLQueue(LQueue *Q, NodePtr pMove)
{
	node* newNode = (struct node*)malloc(sizeof(struct node));
	if (!newNode)
		return false;
	newNode->next = NULL;
	newNode->data = pMove->value;
	newNode->pMove = pMove;
	if (Q->length == 0)
	{
		Q->front = Q->rear = newNode;
	}
	else
	{
		Q->rear->next = newNode;
		Q->rear = newNode;
	}
	Q->length++;
	
	return true;

}

/**
 *  @name        : Status DeLQueue(LQueue *Q)
 *    @description : ���Ӳ���
 *    @param         Q ����ָ��Q
 *    @return         : �ɹ�-TRUE; ʧ��-FALSE
 *  @notice      : None
 */
Status DeLQueue(LQueue *Q)
{
	if (Q->length == 0)
		return false;
	node* nextNode = Q->front->next;
	Q->front = nextNode;
	Q->length--;
	return true;
}



