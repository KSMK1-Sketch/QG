#include<stdio.h>
#include<malloc.h>
#include <stdlib.h>
#include"binary_sort_tree.h"
#include "LQueue.h" 
/**
 * BST initialize
 * @param BinarySortTreePtr BST
 * @return is complete
 */
Status BST_init(BinarySortTreePtr BST)
{
	if (!BST)
		return failed;
	BST->root = (Node*)malloc(sizeof(Node));
	BST->root = NULL;
	return succeed;
}

/**
 * BST insert
 * @param BinarySortTreePtr BST
 * @param ElemType value to insert
 * @return is successful
 */
Status BST_insert(BinarySortTreePtr BST, ElemType value)
{
	if (!BST->root)
	{
		BinarySortTreePtr temp = (BinarySortTree*)malloc(sizeof(BinarySortTree));
		temp->root = (Node*)malloc(sizeof(Node));
		temp->root->value = value;
		temp->root->left = temp->root->right = NULL;
		BST->root = temp->root;
		return succeed;
	}
	if (value > BST->root->value)
		BST_insert(&BST->root->right, value);
	else if (value < BST->root->value)
		BST_insert(&BST->root->left, value);
	else
		return failed;

}

/**
 * BST delete
 * @param BinarySortTreePtr BST
 * @param ElemType the value for Node which will be deleted
 * @return is successful
 */
Status BST_delete(BinarySortTreePtr BST, ElemType value)
{
	NodePtr pMove = NULL, parent = NULL, temp = BST->root;
	if (BST == NULL)
		return failed;
	while (temp)
	{
		if (value == temp->value)
		{
			pMove = temp;		//pMoveָ����Ҫɾ���Ľڵ�
			break;
		}
		parent = temp;//���ڵ�
		if (value < temp->value)
			temp = temp->left;
		else
			temp = temp->right;
	}
	if (!pMove)
		return failed;
	//����������һ�ÿ�
	if (pMove->left == NULL || pMove->right == NULL)
	{
		NodePtr subNode = NULL;
		if (pMove->left == NULL)
			subNode = pMove->right;
		else
			subNode = pMove->left;
		if (parent != NULL)
		{
			if (parent->left == pMove)
				parent->left = subNode;
			else
				parent->right = subNode;
		}
		else
			BST->root = subNode;
		return succeed;
	}
	//������������
	NodePtr replacer = pMove, replacerParent = parent;
	//	ǰ��
	temp = pMove->left;
	while (temp!=NULL)
	{
		replacerParent = replacer;
		replacer = temp;
		temp = temp->right;
	}
	//�ݹ�ɾ��
	BST_delete(&replacerParent, replacer->value);
	//�滻�ڵ�
	if (parent!=NULL)
	{
		if (parent->left==pMove)
			parent->left = replacer;
		else
			parent->right = replacer;
	}
	replacer->left = pMove->left;
	replacer->right = pMove->right;
	pMove->left = pMove->right = NULL;
	return succeed;
}

/**
 * BST search
 * @param BinarySortTreePtr BST
 * @param ElemType the value to search
 * @return is exist
 */
Status BST_search(BinarySortTreePtr BST, ElemType value)
{
	if (BST == NULL)
		return failed;
	if (!BST->root)
		return failed;
	if (value > BST->root->value)
		BST_search(&BST->root->right, value);
	else if (value < BST->root->value)
		BST_search(&BST->root->left, value);
	else
		return succeed;

}

/**
 * BST preorder traversal without recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
Status BST_preorderI(BinarySortTreePtr BST, void (*visit)(NodePtr root))
{
	if (!BST->root)
		return succeed;
	NodePtr stack[1024];
	int stackTop = -1;
	NodePtr pMove = BST->root;
	while (stackTop != -1 || pMove)
	{
		//�ҵ������
		while (pMove)
		{
			//��ӡ·������ջ
			visit(pMove);
			stack[++stackTop] = pMove;
			pMove = pMove->left;
		}
		if (stackTop != -1)
		{
			pMove = stack[stackTop--];
			pMove = pMove->right;
		}
	}
}

/**
 * BST preorder traversal with recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
Status BST_preorderR(BinarySortTreePtr BST, void (*visit)(NodePtr root))
{
	if (!BST->root)
		return succeed;
	visit(BST->root);
	BST_preorderR(&BST->root->left, visit);
	BST_preorderR(&BST->root->right, visit);
}

/**
 * BST inorder traversal without recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
Status BST_inorderI(BinarySortTreePtr BST, void (*visit)(NodePtr root))
{
	if (!BST->root)
		return succeed;
	NodePtr stack[1024];
	int stackTop = -1;
	NodePtr pMove = BST->root;
	while (stackTop != -1 || pMove)
	{
		//�ҵ������
		while (pMove)
		{	//��ջ
			stack[++stackTop] = pMove;
			pMove = pMove->left;
		}
		if (stackTop != -1)
		{
			pMove = stack[stackTop--];
			visit(pMove);
			pMove = pMove->right;
		}
	}
}

/**
 * BST inorder traversal with recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
Status BST_inorderR(BinarySortTreePtr BST, void (*visit)(NodePtr root))
{
	if (!BST->root)
		return succeed;
	BST_inorderR(&BST->root->left, visit);
	visit(BST->root);
	BST_inorderR(&BST->root->right, visit);
}

/**
 * BST preorder traversal without recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
Status BST_postorderI(BinarySortTreePtr BST, void (*visit)(NodePtr root))
{
	if (!BST->root)
		return succeed;
	NodePtr stack[1024];
	int stackTop = -1;
	NodePtr pMove = BST->root;
	NodePtr pLastVisit = NULL;//���ʱ��

	while (pMove)
	{	//��ջ
		stack[++stackTop] = pMove;
		pMove = pMove->left;
	}
	while (stackTop != -1)
	{
		pMove = stack[stackTop--];
		//��ǰ�ڵ��Ƿ񱻷���
		if (pMove->right == NULL || pMove->right == pLastVisit)
		{
			visit(pMove);
			pLastVisit = pMove;
		}
		else
		{//�ұ�û������
			stack[++stackTop] = pMove;
			pMove = pMove->right;
			while (pMove)
			{
				stack[++stackTop] = pMove;
				pMove = pMove->left;
			}
		}
	}

}

/**
 * BST postorder traversal with recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
Status BST_postorderR(BinarySortTreePtr BST, void (*visit)(NodePtr root))
{
	if (!BST->root)
		return succeed;
	BST_postorderR(&BST->root->left, visit);
	BST_postorderR(&BST->root->right, visit);
	visit(BST->root);
}
/**
 * BST level order traversal
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
Status BST_levelOrder(BinarySortTreePtr BST, void (*visit)(NodePtr root))
{
	if (!BST->root)
		return succeed;
	LQueue* Q = (LQueue*)malloc(sizeof(LQueue));
	InitLQueue(Q);
	NodePtr pMove = BST->root;
	EnLQueue(Q, pMove);
	while (Q->length != 0)
	{
		visit(Q->front->pMove);
		pMove = Q->front->pMove;
		DeLQueue(Q);
		if (pMove->left)
			EnLQueue(Q, pMove->left);
		if (pMove->right)
			EnLQueue(Q, pMove->right);

	}

}