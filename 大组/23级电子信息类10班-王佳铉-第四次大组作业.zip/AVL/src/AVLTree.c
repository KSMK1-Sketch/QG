#include <stdio.h>
#include<stdlib.h>
#include"AVLTree.h"
#include "LQueue.h" 



int AVLTreeHeight(AVLTree t)
{
	if (t == NULL)
		return 0;
	else
		return t->height;
}

void PrintAVLTreeLevelOrder(AVLTree t)//�������
{
	printf("���������");
	if (t == NULL)
		return;
	LQueue* q = (LQueue*)malloc(sizeof(LQueue));
	InitLQueue(q);
	EnLQueue(q, t);
	AVLTree pMove;
	while (q->length != 0) {
		pMove = q->front->pMove;
		DeLQueue(q);
		printf("%2d ", pMove->data);
		if (pMove->left)
			EnLQueue(q, pMove->left);
		if (pMove->right)
			EnLQueue(q, pMove->right);
	}
	printf("\n");

	DestoryLQueue(q);
}

//LL��
AVLTree SingleLeftRotation(AVLTree A)
{
	AVLTree B = A->left;
	A->left = B->right;
	B->right = A;
	A->height = max(AVLTreeHeight(A->left), AVLTreeHeight(A->right)) + 1;
	B->height = max(AVLTreeHeight(B->left), AVLTreeHeight(B->right)) + 1;
	return B;
}

//RR��
AVLTree SingleRightRotation(AVLTree A)
{
	AVLTree B = A->right;
	A->right = B->left;
	B->left = A;
	A->height = max(AVLTreeHeight(A->left), AVLTreeHeight(A->right)) + 1;
	B->height = max(AVLTreeHeight(B->left), AVLTreeHeight(B->right)) + 1;
	return B;
}

//LR��
AVLTree DoubleLeftRightRotation(AVLTree A)
{
	//�ȶ�������RR��ת
	A->left = SingleRightRotation(A->left);
	//�ڶ�ALL��ת
	return SingleLeftRotation(A);
}

//RL��
AVLTree DoubleRightLeftRotation(AVLTree A)
{
	A->right = SingleLeftRotation(A->left);
	return SingleRightRotation(A);
}

AVLTree AVLTree_Insert(AVLTree t, AVLTreeElemType x)
{
	if (t == NULL)
	{
		t = (AVLTree)malloc(sizeof(struct AVLNode));
		t->data = x;
		t->height = 1;
		t->left = t->right = NULL;
	}
	else if (x < t->data)//������
	{
		t->left = AVLTree_Insert(t->left, x);
		if (AVLTreeHeight(t->left) - AVLTreeHeight(t->right) == 2) 
		{
			if (x < t->left->data) 
				t = SingleLeftRotation(t);//LL			
			else 
				t = DoubleLeftRightRotation(t);//LR	
		}
	}
	else if (x > t->data)//������
	{
		t->right = AVLTree_Insert(t->right, x);
		if (AVLTreeHeight(t->left) - AVLTreeHeight(t->right) == -2) 
		{
			if (x > t->right->data) 
				t = SingleRightRotation(t);//RR			
			else 
				t = DoubleRightLeftRotation(t);//RL			
		}
	}  //else x==t->data���������
	t->height = max(AVLTreeHeight(t->left), AVLTreeHeight(t->right)) + 1;
	return t;
}
