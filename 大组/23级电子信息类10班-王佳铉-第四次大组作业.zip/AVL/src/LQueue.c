#include "LQueue.h" 
#include <stdio.h>
#include <malloc.h>
#include <assert.h> 
#include"AVLTree.h"


/**
 *  @name        : void InitLQueue(LQueue *Q)
 *    @description : ��ʼ������
 *    @param         Q ����ָ��Q
 *  @notice      : None
 */
void* InitLQueue(LQueue* Q)
{
	Q->front = Q->rear = NULL;
	Q->length = 0;
}

/**
 *  @name        : void DestoryLQueue(LQueue *Q)
 *    @description : ���ٶ���
 *    @param         Q ����ָ��Q
 *  @notice      : None
 */
void DestoryLQueue(LQueue *Q)
{
	if (Q->length == 0)
		return;
	ClearLQueue(Q);
	free(Q->front);
	
}




/**
 *  @name        : Status EnLQueue(LQueue *Q, void *data)
 *    @description : ��Ӳ���
 *    @param         Q ����ָ��Q,�������ָ��data
 *    @return         : �ɹ�-TRUE; ʧ��-FALSE
 *  @notice      : �����Ƿ�Ϊ��
 */
Status EnLQueue(LQueue *Q, AVLTree pMove)
{
	Node* newNode = (struct node*)malloc(sizeof(struct node));
	if (!newNode)
		return FALSE;
	newNode->next = NULL;
	newNode->data = pMove->data;
	newNode->pMove = pMove;
	if (Q->length == 0)
	{
		Q->front = Q->rear = newNode;
	}
	else
	{
		Q->rear->next = newNode;
		Q->rear = newNode;
	}
	Q->length++;

	return TRUE;

}

/**
 *  @name        : Status DeLQueue(LQueue *Q)
 *    @description : ���Ӳ���
 *    @param         Q ����ָ��Q
 *    @return         : �ɹ�-TRUE; ʧ��-FALSE
 *  @notice      : None
 */
Status DeLQueue(LQueue *Q)
{
	if (Q->length == 0)
		return FALSE;
	Node* nextNode = Q->front->next;
	free(Q->front);
	Q->front = nextNode;
	Q->length--;
	return TRUE;
}

/**
 *  @name        : void ClearLQueue(AQueue *Q)
 *    @description : ��ն���
 *    @param         Q ����ָ��Q
 *  @notice      : None
 */
void ClearLQueue(LQueue *Q)
{
	Q->rear = Q->front->next;
	while (Q->front->next)
	{
		Q->rear = Q->rear->next;
		free(Q->front->next);
		Q->front->next = Q->rear;
	}
	free(Q->front->next);
	Q->rear = Q->front;
	Q->length = 0;
}


/**************************************************************
 *    End-Multi-Include-Prevent Section
 **************************************************************/


