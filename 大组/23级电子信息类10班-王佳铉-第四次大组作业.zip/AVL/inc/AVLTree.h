#pragma once
#ifndef AVLTREE_H
#define AVLTREE_H

#define AVLTreeElemType int

typedef struct AVLNode {

    AVLTreeElemType data;
    struct AVLNode* left;
    struct AVLNode* right;
    int height;
}* AVLTree;

void PrintAVLTreeLevelOrder(AVLTree t);//��α���
AVLTree AVLTree_Insert(AVLTree t, AVLTreeElemType x);//����



#endif 