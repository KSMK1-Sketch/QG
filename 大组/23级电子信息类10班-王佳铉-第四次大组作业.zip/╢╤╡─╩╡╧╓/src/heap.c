#include <limits.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include"heap.h"
#include <stdbool.h>
/***************************���ѿռ䴴��*************************************/
MaxHeap CreateMaxHeap(int MaxSize)
{
	MaxHeap H = (MaxHeap)malloc(sizeof(struct HeapNode));	
	H->data = (ElemType*)malloc( sizeof(struct HeapNode)*(MaxSize + 1) );//0�����ڱ���+1
	H->size = 0;
	H->capacity = MaxSize;
	H->data[0] = MAXDATA;//�ڱ�
	return H;
}

/***************************��С�ѿռ䴴��************************************/
MinHeap CreateMinHeap(int MaxSize)
{
	MinHeap H = (MinHeap)malloc(sizeof(struct HeapNode));
	H->data = (ElemType*)malloc((MaxSize + 1) * sizeof(struct HeapNode));
	H->size = 0;
	H->capacity = MaxSize;
	H->data[0] = MINDATA;
	return H;
}

/****************************����************************************/
void DestoryHeap(struct HeapNode* h)
{
	if (h != NULL)
	{
		if (h->data != NULL)
			free(h->data);
		free(h);
	}
}

/*****************************�ж���***********************************/
bool HeapFull(struct HeapNode* H)
{
	return H->size == H->capacity;
}

/*********************************�жϿ�*******************************/
bool HeapEmpty(struct HeapNode* H)
{
	return H->size == 0;
}

/**************************��ӡ**************************************/
void printHeap(struct HeapNode* H)
{
	printf("���������");
	for (int i = 1; i <= H->size; ++i)
		printf("%2d ", H->data[i]);
	printf("\n\n");
}

/**************************���Ѳ���**************************************/
bool InsertMaxHeap(MaxHeap H, ElemType item)
{
	if (HeapFull(H))
		return false;	
	int i = ++H->size;//�Ȳ�������������
	while (item > H->data[i / 2]) //��item�ȸ��ڵ��
	{		
		H->data[i] = H->data[i / 2];//���ڵ�����
		i = i / 2;
	}//����ѭ��,i���룬��ֵ	
	H->data[i] = item;
	return true;
}

/**************************��С�Ѳ���**************************************/
bool InsertMinHeap(MinHeap H, ElemType item)
{
	if (HeapFull(H))
		return false;
	int i = ++H->size;
	while (item < H->data[i / 2]) {
		H->data[i] = H->data[i / 2];
		i = i / 2;
	}
	H->data[i] = item;
	return true;
}

/******************************���Ѷ�ɾ��**********************************/
ElemType DeleteMax(MaxHeap H)
{
	if (HeapEmpty(H)) 
		return H->data[0];
	ElemType MaxItem = H->data[1];
	ElemType tmp = H->data[H->size--];
	int Parent = 1;
	int Child;
	while (Parent * 2 <= H->size) //��tmp�ҵ����ʵ�λ��
	{		
		Child = 2 * Parent;
		
		if ((Child != H->size) && H->data[Child] < H->data[Child + 1]) // ʹChildָ�����Һ����������
			Child++;		
		if (tmp > H->data[Child]) //���tmp>���Һ�������ߣ�˵��tmp���������ѭ��
			break;
		else 
		{			
			H->data[Parent] = H->data[Child];//�ú�������
			Parent = Child;
		}
	}
	H->data[Parent] = tmp;
	return MaxItem;
}

/****************************��С��ɾ��************************************/
ElemType DeleteMin(MinHeap H)
{
	if (HeapEmpty(H)) 
		return H->data[0];
	ElemType MinItem = H->data[1];
	ElemType tmp = H->data[H->size--];
	int Parent = 1;
	int Child;
	while (Parent * 2 <= H->size) 
	{
		Child = 2 * Parent;
		if ((Child != H->size) && H->data[Child + 1] < H->data[Child]) 
			Child++;
		if (tmp < H->data[Child]) 
			break;
		else 
		{
			H->data[Parent] = H->data[Child];
			Parent = Child;
		}
	}
	H->data[Parent] = tmp;
	return MinItem;
}

/***************************�����������¹���************************************/
void percDownMaxHeap(MaxHeap H, int n)
{
	ElemType top;
	int Child;
	int Parent = n;
	top = H->data[n];
	
	for (Parent = n; Parent * 2 <= H->size; Parent = Child) 
	{
		Child = 2 * Parent;
		if (Child != H->size && H->data[Child] < H->data[Child + 1]) 
			Child++;

		if (top >= H->data[Child]) 
			break;
		else		
			H->data[Parent] = H->data[Child];	
	}
	H->data[Parent] = top;
}

/***************************��С�����¹��� *************************************/
void percDownMinHeap(MinHeap H, int n)
{
	ElemType top;
	int Child;
	int Parent = n;
	top = H->data[n];
	for (Parent = n; Parent * 2 <= H->size; Parent = Child)
	{
		Child = 2 * Parent;
		if (Child != H->size && H->data[Child + 1] < H->data[Child]) 
			Child++;
		if (top <= H->data[Child]) 
			break;
		else 
			H->data[Parent] = H->data[Child];		
	}
	H->data[Parent] = top;
}

/**********************���ѳ�ʼ��******************************************/
void initMaxHeap(struct HeapNode* H)
{
	for (int i = (H->size / 2); i > 0; i--) //�����һ���ж��ӵĽڵ㿪ʼ
		percDownMaxHeap(H, i);	
}

/************************��С�ѳ�ʼ��****************************************/
void initMinHeap(struct HeapNode* H)
{	
	for (int i = (H->size / 2); i > 0; i--) 
		percDownMinHeap(H, i);	
}