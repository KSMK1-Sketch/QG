#pragma once

#ifndef HEAP_H
#define HEAP_H

//�ڱ�ֵ
#define MAXDATA INT_MAX
#define MINDATA INT_MIN
#include <stdbool.h>
typedef int ElemType;

struct HeapNode {
    ElemType* data;
    int size;
    int capacity;
};
typedef struct HeapNode* MaxHeap;
typedef struct HeapNode* MinHeap;

/***************************�ѿռ䴴��*************************************/
MaxHeap CreateMaxHeap(int MaxSize);
MinHeap CreateMinHeap(int MaxSize);

/****************************����************************************/
void DestoryHeap(struct HeapNode* h);
bool HeapFull(struct HeapNode* H);
bool HeapEmpty(struct HeapNode* H);
/**************************��ӡ**************************************/
void printHeap(struct HeapNode* H);
/**************************�Ѳ���**************************************/
bool InsertMaxHeap(MaxHeap H, ElemType item);
bool InsertMinHeap(MinHeap H, ElemType item);
/******************************�Ѷ�ɾ��**********************************/
ElemType DeleteMax(MaxHeap H);
ElemType DeleteMin(MinHeap H);

/**********************�����ʼ��Ϊ��******************************************/
void initMaxHeap(struct HeapNode* H);
void initMinHeap(struct HeapNode* H);

#endif 