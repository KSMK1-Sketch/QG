#include"rbTree.h"
#include <stdio.h>
#include <stdlib.h>

void initNIL()//Ҷ�ӽڵ��ʼ��
{
	NIL->key = 0;
	NIL->color = 1;
	NIL->lchild = NIL->rchild = NIL;
	return;
}

Node* creatNode(int value)
{
	Node* p = (Node*)malloc(sizeof(Node));
	p->key = value;
	p->color = 0;
	p->lchild = p->rchild = NIL;
	return p;
}

// �ж��Ƿ��к�ɫ����
int has_red_child(Node* root)
{
	return root->lchild->color == 0 || root->rchild->color == 0;
}

//����
Node* left_rotate(Node* root)
{
	Node* temp = root->rchild;
	root->rchild = temp->lchild;
	temp->lchild = root;
	return temp;
}

//����
Node* right_rotate(Node* root) {
	Node* temp = root->lchild;
	root->lchild = temp->rchild;
	temp->rchild = root;
	return temp;
}

//����
Node* insert_maintain(Node* root) {
	// root��û�к��ӽڵ㣬���õ���
	if (!has_red_child(root)) return root;
	int flag = 0;
	// root�������ӽڵ㶼�Ǻ�ɫ
	if (root->lchild->color == 0 && root->rchild->color == 0)
		goto insert_end;
	// ����ڵ�Ϊ��,root��LCΪ�첢��LC��LCҲ�Ǻ�
	if (root->lchild->color == 0 && has_red_child(root->lchild))
		flag = 1;
	// ����ڵ�Ϊ��,root��RCΪ�첢��RC��RCҲ�Ǻ�
	if (root->rchild->color == 0 && has_red_child(root->rchild))
		flag = 2;
	if (flag == 0) 
		return root;
	if (flag == 1) 
	{
		if (root->lchild->rchild->color == 0) 
			root->lchild = left_rotate(root->lchild);		
		root = right_rotate(root);
	}
	else {
		if (root->rchild->lchild == 0) 
			root->rchild = right_rotate(root->rchild);		
		root = left_rotate(root);
	}
	
insert_end:// ������ɫ
	root->color = 0;
	root->lchild->color = root->rchild->color = 1;
	return root;
}

Node* __insert(Node* root, int val) {
	if (root == NIL) return creatNode(val);
	if (root->key == val) return root;
	if (val < root->key) root->lchild = __insert(root->lchild, val);
	else root->rchild = __insert(root->rchild, val);
	return insert_maintain(root);
}

Node* insert(Node* root, int val)
{
	root = __insert(root, val);
	root->color = 1;
	return root;
}

void clear(Node* root)
{
	if (root == NIL) return;
	clear(root->lchild);
	clear(root->rchild);
	free(root);
	return;
}

void print(Node* root) //��ӡ����
{
	printf("  %d  |  %d  ,  %d  ,  %d \n",
		root->color, root->key, root->lchild->key, root->rchild->key);
	return;
}

void output(Node* root)//�����ӡ
{
	if (root == NIL) return;
	print(root);
	output(root->lchild);
	output(root->rchild);
	return;
}
