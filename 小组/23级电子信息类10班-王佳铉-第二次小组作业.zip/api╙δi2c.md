# API与I2C
2024年4月13日

## 一、API
___
### (1)简介
  &emsp; SPI（Serial Peripheral Interface）通信是一种高速的、全双工的串行通信方式，常用于相邻芯片之间的通信。SPI通信使用4条线实现，分别是SCLK（时钟）、MOSI（主输出从输入）、MISO（主输入从输出）、SS（片选）。在51单片机中，通常采用P1.5（SCLK）、P1.6（MOSI）、P1.7（MISO）和P1.4（SS）引脚实现SPI通信。
   &emsp; SPI通信的优点在于高速、全双工的通信方式，可以实现多路通信。但其缺点在于连接的芯片数量受限，且显然不适合远距离通信。
### (2)代码
___

<details><summary>SPI驱动函数</summary>

```c
#include <reg51.h>  
  
sbit SCK=P3^4;       //将SCK位定义为P3.4
sbit SI=P3^5;        //将SI位定义为P3.5
sbit SO=P3^6;        //将SO位定义为P3.6
sbit CS=P3^7;        //将CS定义为P3.7

#define WREN 0x06    //写使能锁存器允许
#define WRDI 0x04    //写使能锁存器禁止
#define READ 0x03    //读出
#define WRITE 0x02   //写入

 /**
  * @brief  SPI读写单字节数据程序
  * @param  dat
  * @retval read_data
  */
unsigned char SPI_WriteReadByte(unsigned char  dat)
{           
    unsigned char i = 0;
    unsigned char temp = 0;
    unsigned char read_data = 0x00;
//	SCK=0;
    for(i=0;i<8;i++) 
	{            
	    SCK=0;
        temp=((dat&0x80)==0x80)?1:0;
        dat= dat<<1;	
	    SI=temp;
	    SCK=1;
        read_data <<=1;
        read_data|=(unsigned char)SO; 
     }
//	SCK=1;	
    return read_data;
}

/*
  * @brief  SPI 写一个字节
  * @param  dat 写入数据，addr 地址
  * @retval readdat 
  */
unsigned char WriteSet(unsigned char dat,unsigned char addr)
{
            
    unsigned char readdat;
    SCK=0;                 //将SCK置于已知状态
    CS=0;                  //拉低CS，选中X5045
    SPI_WriteReadByte(WREN);    //写使能锁存器允许
    CS=1;                  //拉高CS
    CS=0;                  //重新拉低CS，否则下面的写入指令将被丢弃
	SPI_WriteReadByte(WRITE);   //写入指令
	SPI_WriteReadByte(addr);    //写入指定地址
    SPI_WriteReadByte(dat);     //写入数据
	CS=1;                  //拉高CS
    SCK=0;                 //将SCK置于已知状态
	return readdat;
}

/**
  * @brief  SPI 读一个字节
  * @param  addr 地址
  * @retval dat 读出的数据
  */
unsigned char ReadSet(unsigned char addr)
{
            
    unsigned char dat;

    SCK=0;                 //将SCK置于已知状态
    CS=0;                  //拉低CS，选中X5045
    SPI_WriteReadByte(READ);   //开始读
    SPI_WriteReadByte(addr);   //写入指定地址
    dat=SPI_WriteReadByte(addr);    //读出数据
    CS=1;                 //拉高CS
    SCK=0;                //将SCK置于已知状态
    return dat;           //返回读出的数据 
}

```
</details>

---
<details><summary>测试程序</summary>

```c
void main(void)
{             
  while(1)
  {            
	 WriteSet(0xaa,0x10);   //将数据“0xaa”写入第一个X5045的指定地址“0x10”
	 delaynms(10);           //X5045的写入周期为约10ms
     P1=ReadSet(0x10);       //将数据从第一个X5045中的指定地址读出来	 
  } 
}
```

</details>

---
<details><summary>运行结果</summary>

<img src="text.png"/>
 </details>



## 二、I2C
___
### (1)简介
&emsp;I2C（Inter-Integrated Circuit）通信也是一种常用的通信方式，适用于在短距离、多从设备之间进行通信。I2C通信使用两条线实现，分别是SDA（数据线）和SCL（时钟线）。在51单片机中，通常采用P1.7（SDA）和P1.6（SCL）引脚实现I2C通信。
&emsp;I2C通信的优点在于连接的从设备数量较多，适用于复杂的通信场景。但其缺点在于传输距离较短、受干扰的情况下易出错。
### (2)代码
___
<details><summary>I2C驱动函数</summary>

```c
#include <REGX52.H>

sbit I2C_SCL=P2^1;
sbit I2C_SDA=P2^0;

/**
  * @brief  I2C开始
  * @param  无
  * @retval 无
  */
void I2C_Start(void)
{
	I2C_SDA=1;
	I2C_SCL=1;
	I2C_SDA=0;
	I2C_SCL=0;
}

/**
  * @brief  I2C停止
  * @param  无
  * @retval 无
  */
void I2C_Stop(void)
{
	I2C_SDA=0;
	I2C_SCL=1;
	I2C_SDA=1;
}

/**
  * @brief  I2C发送一个字节
  * @param  Byte 要发送的字节
  * @retval 无
  */
void I2C_SendByte(unsigned char Byte)
{
	unsigned char i;
	for(i=0;i<8;i++)
	{
		I2C_SDA=Byte&(0x80>>i);
		I2C_SCL=1;
		I2C_SCL=0;
	}
}

/**
  * @brief  I2C接收一个字节
  * @param  无
  * @retval 接收到的一个字节数据
  */
unsigned char I2C_ReceiveByte(void)
{
	unsigned char i,Byte=0x00;
	I2C_SDA=1;
	for(i=0;i<8;i++)
	{
		I2C_SCL=1;
		if(I2C_SDA){Byte|=(0x80>>i);}
		I2C_SCL=0;
	}
	return Byte;
}

/**
  * @brief  I2C发送应答
  * @param  AckBit 应答位，0为应答，1为非应答
  * @retval 无
  */
void I2C_SendAck(unsigned char AckBit)
{
	I2C_SDA=AckBit;
	I2C_SCL=1;
	I2C_SCL=0;
}

/**
  * @brief  I2C接收应答位
  * @param  无
  * @retval 接收到的应答位，0为应答，1为非应答
  */
unsigned char I2C_ReceiveAck(void)
{
	unsigned char AckBit;
	I2C_SDA=1;
	I2C_SCL=1;
	AckBit=I2C_SDA;
	I2C_SCL=0;
	return AckBit;
}
```
</details>

---
<details><summary>利用I2C实现AT24C02的数据储存和读取</summary>

```c
#include <REGX52.H>
#include "I2C.h"

#define AT24C02_ADDRESS		0xA0

/**
  * @brief  AT24C02写入一个字节
  * @param  WordAddress 要写入字节的地址
  * @param  Data 要写入的数据
  * @retval 无
  */
void AT24C02_WriteByte(unsigned char WordAddress,Data)
{
	I2C_Start();
	I2C_SendByte(AT24C02_ADDRESS);
	I2C_ReceiveAck();
	I2C_SendByte(WordAddress);
	I2C_ReceiveAck();
	I2C_SendByte(Data);
	I2C_ReceiveAck();
	I2C_Stop();
}

/**
  * @brief  AT24C02读取一个字节
  * @param  WordAddress 要读出字节的地址
  * @retval 读出的数据
  */
unsigned char AT24C02_ReadByte(unsigned char WordAddress)
{
	unsigned char Data;
	I2C_Start();
	I2C_SendByte(AT24C02_ADDRESS);
	I2C_ReceiveAck();
	I2C_SendByte(WordAddress);
	I2C_ReceiveAck();
	I2C_Start();
	I2C_SendByte(AT24C02_ADDRESS|0x01);
	I2C_ReceiveAck();
	Data=I2C_ReceiveByte();
	I2C_SendAck(1);
	I2C_Stop();
	return Data;
}
```
</details>

---
<details><summary>测试程序</summary>

```c
#include <REGX52.H>

unsigned char Num=8;

void main()
{
	Timer0Init();
	AT24C02_WriteByte(0,Num);
	Num=0;
	Delay(5);
	Num=AT24C02_ReadByte(0);
	while(1)
	{
		Nixie_SetBuf(1,Num);	//设置显示缓存，显示数据
	}
}
```
</details>

---
<details><summary>运行结果</summary>

<img src="text1.png"/>
 </details>

